/*!
 * tnemaserver
 * Copyright(c) 2017 Deberson Paula
 * MIT Licensed
 */

'use strict';

module.exports = require('./lib/main');