/*!
 * tnemaserver
 * Copyright(c) 2017 Deberson Paula
 * MIT Licensed
 */
import { TNEMAServer } from './lib/main';
export { TNEMAServer };
